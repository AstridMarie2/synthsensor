library(synthsensor)
app_synth()
