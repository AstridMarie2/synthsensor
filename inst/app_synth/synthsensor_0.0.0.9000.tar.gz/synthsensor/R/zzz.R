utils::globalVariables(c(
  "Date", "Sensor1", "Sensor2", "Diff", "start", "end", "type"
))
